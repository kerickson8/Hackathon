import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;

public class RandQuestion implements ActionListener {
	
	@Override
    public void actionPerformed(ActionEvent e) {
		this.setBackground(Color.red);
	}

}
